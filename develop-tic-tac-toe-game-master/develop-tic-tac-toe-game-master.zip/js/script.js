// button click handler
const play = () => {

    // var box1, box2, box3, box4, box5, box6, box7, box8, box9;
    // box1 = document.getElementById("box-1").innerText;
    // box2 = document.getElementById("box-2").innerText;
    // box3 = document.getElementById("box-3").innerText;
    // box4 = document.getElementById("box-4").innerText;
    // box5 = document.getElementById("box-5").innerText;
    // box6 = document.getElementById("box-6").innerText;
    // box7 = document.getElementById("box-7").innerText;
    // box8 = document.getElementById("box-8").innerText;
    // box9 = document.getElementById("box-9").innerText;

    //apply event to generate new game state




    // game state renderer renders the generated game state

    // renders text on button clicked with X or O

    

    // disable the button clicked

    // update panel values such as Turn Played By and Moves Left

    // reset panel values to default values


    // implement logic to get the winner

    // announce winner
}

// REPLAY-MODE :: replay-game-button-clicked->fetches events recorded->apply event->generates new game state->render game state


// reset game to start a new
// const resetGame = () => {

//     console.log("Game Resetted");
//     //reset player turn to x
//     document.getElementById('next-player').innerText = 'Turn Played By: X';

//     //reset all buttons
//     document.getElementById("box-1").innerText = "";
//     document.getElementById("box-2").innerText = "";
//     document.getElementById("box-3").innerText = "";
//     document.getElementById("box-4").innerText = "";
//     document.getElementById("box-5").innerText = "";
//     document.getElementById("box-6").innerText = "";
//     document.getElementById("box-7").innerText = "";
//     document.getElementById("box-8").innerText = "";
//     document.getElementById("box-9").innerText = "";
// }


// bind events to clickable buttons
// function enableButtons() {

//     //on click for restart game
//     // document.getElementById("reset").click(() => console.log("reset"))
//     document.getElementById("reset").addEventListener("click",resetGame)

//     // resetGame();
// }

module.exports = play;
